<?php

namespace StripeJS\Error;

class RateLimit extends InvalidRequest
{
}
