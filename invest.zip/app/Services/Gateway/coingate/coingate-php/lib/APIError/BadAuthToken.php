<?php

namespace CoinGate\APIError;

# HTTP Status 401
class BadAuthToken extends Unauthorized
{
}
