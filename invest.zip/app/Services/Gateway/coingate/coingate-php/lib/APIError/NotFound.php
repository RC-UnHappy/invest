<?php

namespace CoinGate\APIError;

# HTTP Status 404
class NotFound extends APIError
{
}
